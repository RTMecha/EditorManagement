# waveform-2D
How do i display a waveform in a Unity 2D project?  I create a Texture2D within a script that I have mapped the samples of an audio track on. I use AudioClip.GetData to get all the samples at once. And use texture2d.SetPixel to draw the waveform on the texture before assigning to a Sprite GameObject. 

YouTube:  https://youtu.be/I-ccHsppDLc
